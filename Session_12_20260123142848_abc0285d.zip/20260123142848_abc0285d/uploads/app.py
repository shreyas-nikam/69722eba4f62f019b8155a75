# app.py
import streamlit as st
import pandas as pd
import json
import os
import hashlib
import datetime

from source import (
    setup_analysis_environment,
    safe_extract_zip,
    discover_files,
    find_first_by_name,
    read_text_file,
    store_config_snapshot,
    scan_code_files_for_insecure_deserialization_and_consolidate,
    scan_code_for_insecure_deserialization_and_consolidate,
    detect_dependency_hallucinations,
    create_risk_scorecard,
    generate_sdlc_control_recommendations,
    generate_executive_summary,
    save_reports,
    create_evidence_manifest,
    bundle_artifacts_to_zip,
)

# -----------------------------
# UI Header
# -----------------------------
st.set_page_config(
    page_title="QuLab: Lab 12: AI Code-Generation Risk Analyzer", layout="wide")
st.sidebar.image("https://www.quantuniversity.com/assets/img/logo5.jpg")
st.sidebar.divider()
st.title("QuLab: Lab 12: AI Code-Generation Risk Analyzer")
st.divider()

# -----------------------------
# Defaults
# -----------------------------
DEFAULT_PYTHON_CODE = """import os
import subprocess
import pickle
import base64
import sqlite3

API_KEY = "sk_prod_12345" # Critical: Hardcoded API key
DEBUG_MODE = True
SECRET_PHRASE = "this_is_a_secret" # Critical: Another hardcoded secret

def authenticate(password):
    if password == SECRET_PHRASE:
        print("Authentication successful.")
        return True
    return False

def execute_command(command):
    # Potential Command Injection
    subprocess.run(f"echo {command}", shell=True) # High: Use of shell=True with user input

def evaluate_expression(expr):
    # Unsafe eval/exec
    return eval(expr) # Critical: Unsafe use of eval

def get_user_data(username):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    # Potential SQL Injection
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query) # Critical: Unsafe string concatenation in SQL query
    user_data = cursor.fetchone()
    conn.close()
    return user_data

def process_serialized_data(encoded_data):
    # Insecure Deserialization
    data = base64.b64decode(encoded_data)
    obj = pickle.loads(data) # Critical: Insecure use of pickle.loads
    return obj

def process_request(request):
    user_input = request.get('input', '')
    if 'eval_code' in request:
        evaluate_expression(request['eval_code'])
    elif 'cmd' in request:
        execute_command(request['cmd'])
    elif 'username' in request:
        get_user_data(request['username'])
    elif 'serialized_data' in request:
        process_serialized_data(request['serialized_data'])

    # False positive suppression example: a string that looks like a secret but isn't
    user_id_prefix = "user_identifier_" + str(hash(user_input)) # Not a secret
    return {"status": "processed", "user_id_prefix": user_id_prefix}"""

DEFAULT_REQUIREMENTS_CONTENT = """flask==2.1.0
requests==2.28.1
unknown-package-malware==1.0.0 # This should be flagged
sqlalchemy==1.4.32"""

DEFAULT_ALLOWLIST_JSON = json.dumps({
    "flask": ["2.1.0", "2.2.0"],
    "requests": ["2.28.1", "2.29.0", "2.30.0"],
    "sqlalchemy": ["1.4.32", "2.0.0"]
}, indent=4)

DEFAULT_ALLOWLIST_JSON = json.dumps({
    "flask": ["2.1.0", "2.2.0"],
    "requests": ["2.28.1", "2.29.0", "2.30.0"],
    "sqlalchemy": ["1.4.32", "2.0.0"]
}, indent=4)


def compute_sha256_from_string(content: str) -> str:
    if not content:
        return ""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def save_uploaded_streamlit_file(uploaded_file, dest_path: str) -> str:
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    with open(dest_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return dest_path


def persist_text_inputs(report_path: str, python_code: str, requirements: str, allowlist_json_str: str) -> dict:
    """
    Persist textarea inputs as files so they appear in the artifact zip.
    """
    code_path = os.path.join(report_path, "pasted_code.py")
    req_path = os.path.join(report_path, "requirements.txt")
    allow_path = os.path.join(report_path, "dependency_allowlist.json")

    with open(code_path, "w", encoding="utf-8") as f:
        f.write(python_code or "")

    with open(req_path, "w", encoding="utf-8") as f:
        f.write(requirements or "")

    try:
        allow_obj = json.loads(allowlist_json_str or "{}")
    except json.JSONDecodeError:
        allow_obj = {}
    with open(allow_path, "w", encoding="utf-8") as f:
        json.dump(allow_obj, f, indent=4)

    return {"code_paths": [code_path], "requirements_path": req_path, "allowlist_path": allow_path}


# -----------------------------
# Session State
# -----------------------------
if "session_id" not in st.session_state or st.session_state.session_id is None:
    st.session_state.session_id, st.session_state.report_path = setup_analysis_environment()

st.session_state.setdefault("current_page", "Home")
st.session_state.setdefault("python_code", DEFAULT_PYTHON_CODE)
st.session_state.setdefault("requirements_content",
                            DEFAULT_REQUIREMENTS_CONTENT)
st.session_state.setdefault(
    "dependency_allowlist_json_str", DEFAULT_ALLOWLIST_JSON)

try:
    st.session_state.setdefault(
        "dependency_allowlist", json.loads(DEFAULT_ALLOWLIST_JSON))
except json.JSONDecodeError:
    st.session_state.setdefault("dependency_allowlist", {})

st.session_state.setdefault("generation_method", "Copilot")
st.session_state.setdefault("human_review_level", "Partial")
st.session_state.setdefault("analysis_done", False)

st.session_state.setdefault("df_all_static_findings", pd.DataFrame())
st.session_state.setdefault("df_dependency_findings", pd.DataFrame())
st.session_state.setdefault("df_consolidated_findings", pd.DataFrame())
st.session_state.setdefault("risk_summary_data", {})
st.session_state.setdefault("sdlc_recommendations_markdown", "")
st.session_state.setdefault("executive_summary_markdown", "")
st.session_state.setdefault("evidence_manifest_filepath", None)
st.session_state.setdefault("zip_archive_filepath", None)

# -----------------------------
# Sidebar Navigation
# -----------------------------
with st.sidebar:
    page_selection = st.selectbox(
        "Navigation",
        ["Home", "1. Code & Context Input", "2. Static Analysis Findings", "3. Dependency Analysis",
         "4. Consolidated Risk & Controls", "5. Report Export"],
        key="page_selector",
    )
    st.session_state.current_page = page_selection


# -----------------------------
# Pages
# -----------------------------
if st.session_state.current_page == "Home":

    st.markdown(
        f"## Introduction: Securing AI-Generated Code at InnovateTech Solutions")
    st.markdown(f"Alice plays a crucial role in maintaining the security posture of InnovateTech Solutions' applications. With the adoption of AI-powered code generation tools, her team must ensure AI-generated code adheres to strict secure coding standards before integration into critical systems.")
    st.markdown(f"Today, Alice received a Python API handler that was largely generated by Copilot. Before this code can proceed to the next SDLC stage, Alice will perform a thorough security review. Her objectives:")
    st.markdown(f"""- Detect hard-coded secrets
- Identify injection flaws (SQL/Command)
- Spot unsafe deserialization
- Verify dependencies against an allowlist
- Produce a consolidated, prioritized vulnerability report and remediation plan
""")
    st.markdown(f"This application simulates Alice's workflow using heuristic and AST-based static analysis, dependency verification, and a comprehensive vulnerability report for InnovateTech Solutions.")
    st.markdown(f"---")
    st.markdown(f"### Learning Objectives")
    st.markdown(f"By completing this lab, you will be able to:")
    st.markdown(f"""1. Identify common failure modes in AI-generated code.
2. Detect insecure patterns using static heuristics.
3. Flag dependency hallucinations and supply-chain risks.
4. Define SDLC control gates for AI-assisted development.
5. Produce audit-ready code-gen risk reports.""")

elif st.session_state.current_page == "1. Code & Context Input":

    st.markdown("## 1. Code & Context Input")

    st.markdown("### Upload Python Files (multiple) OR Upload a ZIP")
    uploaded_py_files = st.file_uploader(
        "Upload one or more .py files",
        type=["py"],
        accept_multiple_files=True,
        key="py_uploader"
    )

    uploaded_zip = st.file_uploader(
        "Or upload a .zip containing code + optional requirements.txt + dependency_allowlist.json",
        type=["zip"],
        accept_multiple_files=False,
        key="zip_uploader"
    )

    st.markdown("---")
    st.markdown("### Fallback: Paste Code (used only if no uploads)")
    st.session_state.python_code = st.text_area(
        "Python Code",
        value=st.session_state.python_code,
        height=250,
        key="python_code_input",
    )

    st.markdown(
        "### Dependency Context (used if ZIP does not include these files)")
    st.session_state.requirements_content = st.text_area(
        "Requirements.txt Content (Optional)",
        value=st.session_state.requirements_content,
        height=120,
        key="requirements_input",
    )

    st.session_state.dependency_allowlist_json_str = st.text_area(
        "Dependency Allowlist (JSON)",
        value=st.session_state.dependency_allowlist_json_str,
        height=180,
        key="allowlist_input",
    )

    try:
        st.session_state.dependency_allowlist = json.loads(
            st.session_state.dependency_allowlist_json_str)
    except json.JSONDecodeError:
        st.error("Invalid JSON in Dependency Allowlist. Please check the format.")
        st.session_state.dependency_allowlist = {}

    st.markdown("### Generation Context")
    generation_options = ["Copilot", "Claude", "Agent"]
    st.session_state.generation_method = st.selectbox(
        "AI Generation Method",
        generation_options,
        index=generation_options.index(st.session_state.generation_method)
        if st.session_state.generation_method in generation_options else 0,
        key="generation_method_selector",
    )

    review_options = ["None", "Partial", "Full"]
    st.session_state.human_review_level = st.selectbox(
        "Human Review Level",
        review_options,
        index=review_options.index(st.session_state.human_review_level)
        if st.session_state.human_review_level in review_options else 1,
        key="review_level_selector",
    )

    if st.button("Run Analysis", key="run_analysis_button"):
        with st.spinner("Running analysis..."):
            # Ensure environment exists
            if st.session_state.session_id is None or st.session_state.report_path is None:
                st.session_state.session_id, st.session_state.report_path = setup_analysis_environment()

            report_path = st.session_state.report_path
            uploads_dir = os.path.join(report_path, "uploads")
            extracted_dir = os.path.join(report_path, "extracted_zip")
            os.makedirs(uploads_dir, exist_ok=True)

            code_paths = []
            requirements_content = None
            allowlist_obj = None
            requirements_fp = None
            allowlist_fp = None

            # ---- Path A: ZIP upload ----
            if uploaded_zip is not None:
                zip_path = os.path.join(uploads_dir, uploaded_zip.name)
                save_uploaded_streamlit_file(uploaded_zip, zip_path)

                safe_extract_zip(zip_path, extracted_dir)

                # discover .py files
                code_paths = discover_files(extracted_dir, exts=(".py",))

                # optional: pull requirements + allowlist from zip if present
                requirements_fp = find_first_by_name(
                    extracted_dir, "requirements.txt")
                allowlist_fp = find_first_by_name(
                    extracted_dir, "dependency_allowlist.json")

                if requirements_fp and os.path.exists(requirements_fp):
                    requirements_content = read_text_file(requirements_fp)
                if allowlist_fp and os.path.exists(allowlist_fp):
                    try:
                        allowlist_obj = json.loads(
                            read_text_file(allowlist_fp))
                    except json.JSONDecodeError:
                        allowlist_obj = {}

                if not code_paths:
                    st.error(
                        "ZIP uploaded, but no .py files were found inside it.")
                    st.stop()

            # ---- Path B: multiple .py uploads ----
            elif uploaded_py_files:
                for f in uploaded_py_files:
                    dest = os.path.join(uploads_dir, f.name)
                    save_uploaded_streamlit_file(f, dest)
                    code_paths.append(dest)

            # ---- Path C: fallback to textarea ----
            else:
                if not st.session_state.python_code.strip():
                    st.warning(
                        "Please upload code files/zip OR paste Python code.")
                    st.stop()

                persisted = persist_text_inputs(
                    report_path,
                    st.session_state.python_code,
                    st.session_state.requirements_content,
                    st.session_state.dependency_allowlist_json_str,
                )
                code_paths = persisted["code_paths"]
                requirements_fp = persisted["requirements_path"]
                allowlist_fp = persisted["allowlist_path"]
                requirements_content = st.session_state.requirements_content
                allowlist_obj = st.session_state.dependency_allowlist

            # If ZIP did not provide deps, use textarea deps
            if requirements_content is None:
                requirements_content = st.session_state.requirements_content
            if allowlist_obj is None:
                allowlist_obj = st.session_state.dependency_allowlist

            # If we still don't have allowlist (bad JSON), force empty dict
            if not isinstance(allowlist_obj, dict):
                allowlist_obj = {}

            # Store config snapshot (multi-file aware)
            store_config_snapshot(
                report_path=report_path,
                run_id=st.session_state.session_id,
                code_filepaths=code_paths,
                requirements_filepath=requirements_fp,
                allowlist_filepath=allowlist_fp,
                ai_generation_method=st.session_state.generation_method,
                human_review_level=st.session_state.human_review_level,
                extra={
                    "num_code_files": len(code_paths),
                    "uploaded_zip": uploaded_zip.name if uploaded_zip else None,
                    "uploaded_py_files": [f.name for f in uploaded_py_files] if uploaded_py_files else None,
                    "requirements_hash_sha256_from_textarea": compute_sha256_from_string(st.session_state.requirements_content),
                    "allowlist_hash_sha256_from_textarea": compute_sha256_from_string(st.session_state.dependency_allowlist_json_str),
                }
            )

            # ---- 1) Static Analysis across all code files ----
            if len(code_paths) == 1:
                code_str = read_text_file(code_paths[0])
                st.session_state.df_all_static_findings = pd.DataFrame(
                    [dict(f, file_path=code_paths[0])
                     for f in scan_code_for_insecure_deserialization_and_consolidate(code_str)]
                )
            else:
                st.session_state.df_all_static_findings = scan_code_files_for_insecure_deserialization_and_consolidate(
                    code_paths)

            # ---- 2) Dependency Analysis ----
            dep_findings = detect_dependency_hallucinations(
                requirements_content or "", allowlist_obj)
            st.session_state.df_dependency_findings = pd.DataFrame(
                dep_findings)

            dep_json_path = os.path.join(
                report_path, "dependency_findings.json")
            st.session_state.df_dependency_findings.to_json(
                dep_json_path, orient="records", indent=4)

            # ---- 3) Risk Scoring ----
            st.session_state.df_consolidated_findings, st.session_state.risk_summary_data = create_risk_scorecard(
                st.session_state.df_all_static_findings,
                st.session_state.df_dependency_findings,
            )

            # ---- 4) SDLC + Executive ----
            st.session_state.sdlc_recommendations_markdown = generate_sdlc_control_recommendations(
                st.session_state.risk_summary_data
            )
            st.session_state.executive_summary_markdown = generate_executive_summary(
                st.session_state.session_id,
                st.session_state.risk_summary_data,
                st.session_state.sdlc_recommendations_markdown,
            )

            # ---- 5) Save reports ----
            save_reports(
                report_path=report_path,
                run_id=st.session_state.session_id,
                df_consolidated=st.session_state.df_consolidated_findings,
                risk_summary=st.session_state.risk_summary_data,
                sdlc_md=st.session_state.sdlc_recommendations_markdown,
                exec_md=st.session_state.executive_summary_markdown,
            )

            # ---- 6) Evidence + ZIP ----
            st.session_state.evidence_manifest_filepath = create_evidence_manifest(
                report_path)
            st.session_state.zip_archive_filepath = bundle_artifacts_to_zip(
                report_path, st.session_state.session_id)

            st.session_state.analysis_done = True
            st.success(
                f"Analysis complete! Processed {len(code_paths)} code file(s).")

elif st.session_state.current_page == "2. Static Analysis Findings":
    st.markdown("## 2. Static Analysis Findings")
    if st.session_state.analysis_done:
        if not st.session_state.df_all_static_findings.empty:
            cols = ["file_path", "risk_type", "severity", "confidence",
                    "line_num", "code_snippet", "description", "remediation"]
            cols = [
                c for c in cols if c in st.session_state.df_all_static_findings.columns]
            st.dataframe(st.session_state.df_all_static_findings[cols])
        else:
            st.info("No static analysis findings detected.")
    else:
        st.warning("Run analysis first in '1. Code & Context Input'.")

elif st.session_state.current_page == "3. Dependency Analysis":
    st.markdown("## 3. Dependency Analysis")
    if st.session_state.analysis_done:
        if not st.session_state.df_dependency_findings.empty:
            cols = ["risk_type", "severity", "confidence", "package", "version",
                    "line_in_requirements_txt", "description", "remediation"]
            cols = [
                c for c in cols if c in st.session_state.df_dependency_findings.columns]
            st.dataframe(st.session_state.df_dependency_findings[cols])
        else:
            st.info("No dependency issues detected.")
    else:
        st.warning("Run analysis first in '1. Code & Context Input'.")

elif st.session_state.current_page == "4. Consolidated Risk & Controls":
    st.markdown("## 4. Consolidated Risk & Controls")
    if st.session_state.analysis_done:
        if not st.session_state.df_consolidated_findings.empty:
            st.markdown("### Risk Summary")
            for k, v in st.session_state.risk_summary_data.items():
                st.markdown(f"- **{k.replace('_', ' ').title()}**: {v}")

            st.markdown("### Consolidated Findings")
            cols = ["file_path", "risk_type", "severity", "confidence", "risk_score",
                    "line_num", "package", "code_snippet", "description", "remediation"]
            cols = [
                c for c in cols if c in st.session_state.df_consolidated_findings.columns]
            st.dataframe(st.session_state.df_consolidated_findings[cols])

            st.markdown("### SDLC Control Recommendations")
            st.markdown(st.session_state.sdlc_recommendations_markdown)
        else:
            st.info("No vulnerabilities detected.")
    else:
        st.warning("Run analysis first in '1. Code & Context Input'.")

elif st.session_state.current_page == "5. Report Export":
    st.markdown("## 5. Report Export")
    if st.session_state.analysis_done:
        st.markdown("### Executive Summary")
        st.markdown(st.session_state.executive_summary_markdown)

        st.markdown("### Download ZIP")
        if st.session_state.zip_archive_filepath and os.path.exists(st.session_state.zip_archive_filepath):
            with open(st.session_state.zip_archive_filepath, "rb") as fp:
                st.download_button(
                    label=f"Download All Reports (Session_{st.session_state.session_id}.zip)",
                    data=fp,
                    file_name=f"Session_{st.session_state.session_id}.zip",
                    mime="application/zip",
                    key="download_all_zip",
                )

        st.markdown("---")
        st.markdown("### Individual Files")
        output_files = {
            "code_findings.json": "application/json",
            "dependency_findings.json": "application/json",
            "risk_scorecard.json": "application/json",
            "sdlc_control_recommendations.md": "text/markdown",
            "session12_executive_summary.md": "text/markdown",
            "config_snapshot.json": "application/json",
            "evidence_manifest.json": "application/json",
        }
        for filename, mime_type in output_files.items():
            filepath = os.path.join(st.session_state.report_path, filename)
            if os.path.exists(filepath):
                with open(filepath, "rb") as fp:
                    st.download_button(
                        label=f"Download {filename}",
                        data=fp,
                        file_name=filename,
                        mime=mime_type,
                        key=f"download_{filename.replace('.', '_')}",
                    )
            else:
                st.info(f"Not generated yet: {filename}")
    else:
        st.warning("Run analysis first in '1. Code & Context Input'.")

# License
st.caption('''
---
## QuantUniversity License

© QuantUniversity 2025
This notebook was created for **educational purposes only** and is **not intended for commercial use**.

- You **may not copy, share, or redistribute** this notebook **without explicit permission** from QuantUniversity.
- You **may not delete or modify this license cell** without authorization.
- This notebook was generated using **QuCreate**, an AI-powered assistant.
- Content generated by AI may contain **hallucinated or incorrect information**. Please **verify before using**.

All rights reserved. For permissions or commercial licensing, contact: info@qusandbox.com
''')
